import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AppConfigService } from './app-config.service';

import { TransaccionesService } from './transacciones.service';
import { TransactionRequest } from '../domain/models/transacciones.model';

describe('TransaccionesService', () => {
  let service: TransaccionesService;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;
  let controller: HttpTestingController;
  beforeEach(() => {

    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
       providers: [TransaccionesService,
       {provide: AppConfigService, useValue: spy}]
    });
    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;
    appConfigServiceSpy.getConfig.and.returnValue({
      "backendUrl": "https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com",
      "svTransaccionesPath": "/transacciones",
      "svTransaccionesCsv": "/to-csv",
      "transaccionPageSize": "20"
    });
    service = TestBed.inject(TransaccionesService);
    controller = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be obtenerTransacciones error', () => {
    let transactionRequest: TransactionRequest = {
      transactionId: '123',
      uniqueCode: 'unicode',
      terminalId: '123',
      fechaTransaccionInicio: '10/10/21',
      fechaTransaccionFinal: '10/10/21',
      estadoTransaccion: 'si',
      tipoTransaccion: 'tipo',
      pageNumber: "0",
      pageSize: "30"
    }


    service.obtenerTransacciones(transactionRequest,1).subscribe(event  => { },
      (err) => {
        expect(err).toBeTruthy();
      });        
   
  
      let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/transacciones?pageNumber=1&pageSize=20&transactionId=123&uniqueCode=unicode&terminalId=123&fechaTransaccionInicio=10/10/21&fechaTransaccionFinal=10/10/21&estadoTransaccion=si&tipoTransaccion=tipo&pageNumber=0&pageSize=30");
      mockReq.flush({ errorType: 2,
        errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
        errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
        { status: 404, statusText: 'Bad Request' });   
         
        expect(service.obtenerTransacciones(transactionRequest,1)).toBeTruthy();
    });
    it('should be obtenerTransacciones 200', () => {
      let transactionRequest: TransactionRequest = {
        transactionId: '123',
        uniqueCode: 'unicode',
        terminalId: '123',
        fechaTransaccionInicio: '10/10/21',
        fechaTransaccionFinal: '10/10/21',
        estadoTransaccion: 'si',
        tipoTransaccion: 'tipo',
        pageNumber: "0",
        pageSize: "30"
      }
  
  
      service.obtenerTransacciones(transactionRequest,1).subscribe(event  => { 
        expect(event).toBeTruthy();
      },
        (err) => {
          
        });        
     
    
        let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/transacciones?pageNumber=1&pageSize=20&transactionId=123&uniqueCode=unicode&terminalId=123&fechaTransaccionInicio=10/10/21&fechaTransaccionFinal=10/10/21&estadoTransaccion=si&tipoTransaccion=tipo&pageNumber=0&pageSize=30");
        mockReq.flush({  });   
           
          
      });
    
    it('should be obtenerTransaccionesCsv with error', () => {
      let transactionRequest: TransactionRequest = {
        transactionId: '123',
        uniqueCode: 'unicode',
        terminalId: '123',
        fechaTransaccionInicio: '10/10/21',
        fechaTransaccionFinal: '10/10/21',
        estadoTransaccion: 'si',
        tipoTransaccion: 'tipo',
        pageNumber: "0",
        pageSize: "30"
      }
  
  
      service.obtenerTransaccionesCsv(transactionRequest).subscribe(event  => { },
        (err) => {
          expect(err).toBeTruthy();
        });        
     
    
        let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/transacciones/to-csv?transactionId=123&uniqueCode=unicode&terminalId=123&fechaTransaccionInicio=10/10/21&fechaTransaccionFinal=10/10/21&estadoTransaccion=si&tipoTransaccion=tipo");
        mockReq.flush({ errorType: 2,
          errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
          errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
          { status: 404, statusText: 'Bad Request' });   
           
          expect(service.obtenerTransacciones(transactionRequest,1)).toBeTruthy();
      });
      
      it('should be obtenerTransaccionesCsv with 200', () => {
        let transactionRequest: TransactionRequest = {
          transactionId: '123',
          uniqueCode: 'unicode',
          terminalId: '123',
          fechaTransaccionInicio: '10/10/21',
          fechaTransaccionFinal: '10/10/21',
          estadoTransaccion: 'si',
          tipoTransaccion: 'tipo',
          pageNumber: "0",
          pageSize: "30"
        }
    
    
        service.obtenerTransaccionesCsv(transactionRequest).subscribe(event  => {
          expect(event).toBeTruthy();
         },
          (err) => {
            
          });        
       
      
          let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/transacciones/to-csv?transactionId=123&uniqueCode=unicode&terminalId=123&fechaTransaccionInicio=10/10/21&fechaTransaccionFinal=10/10/21&estadoTransaccion=si&tipoTransaccion=tipo");
          mockReq.flush({ });   
             
            
        });

      it('should be darFormatearFecha', () => {
        let fecha: Date = new Date();
             
            expect(service.darFormatearFecha(fecha)).toBeInstanceOf(String);
        });

});

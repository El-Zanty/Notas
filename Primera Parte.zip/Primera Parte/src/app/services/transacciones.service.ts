import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TransactionRequest, TransactionResponse } from '../domain/models/transacciones.model';
import { Observable, throwError } from 'rxjs';
import { AppConfigService } from './app-config.service';
import { catchError, map, retry, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TransaccionesService {


  private uri;
  private svTransaccionesPath;
  private svTransaccionesCsv;
  private pageSize;

  constructor(  private http: HttpClient,
                private config: AppConfigService ) {

                  const {backendUrl, svTransaccionesPath, svTransaccionesCsv, svTransaccionesUri, transaccionPageSize, svRegistroTerminales} = config.getConfig();
                  this.uri = backendUrl;
                  this.svTransaccionesPath = svTransaccionesPath;
                  this.svTransaccionesCsv = svTransaccionesCsv;
                  this.pageSize = transaccionPageSize;
                }

  obtenerTransacciones(transactionRequest: TransactionRequest, page: number): Observable<any>{
    const headers = this.obtenerToken();
    return this.http.get<any>
      (`${ this.uri }${ this.svTransaccionesPath }?` +
                                                  `pageNumber=${page}` +
                                                  `&pageSize=${this.pageSize}` +
                                                  `&transactionId=${ transactionRequest.transactionId }`+
                                                  `&uniqueCode=${ transactionRequest.uniqueCode }`+
                                                  `&terminalId=${ transactionRequest.terminalId }`+
                                                  `&fechaTransaccionInicio=${ transactionRequest.fechaTransaccionInicio }`+
                                                  `&fechaTransaccionFinal=${ transactionRequest.fechaTransaccionFinal }`+
                                                  `&estadoTransaccion=${ transactionRequest.estadoTransaccion }`+
                                                  `&tipoTransaccion=${ transactionRequest.tipoTransaccion }` +
                                                  `&pageNumber=${ transactionRequest.pageNumber }` +
                                                  `&pasarela=${ transactionRequest.pasarela }` +
                                                  `&authorizationCode=${ transactionRequest.authorizationCode }`                                                  
      , {headers}).pipe(
        retry(2),
        tap( d => console.log('Servicio de consulta de transacciones')),
        catchError(this.handleError<any>('Servicio de consulta de transacciones'))
    );
  }

  obtenerTransaccionesCsv(transactionRequest: TransactionRequest): Observable<ArrayBuffer> {
    const headers = this.obtenerToken();
    const options = { headers, responseType: 'text' as any };
    return this.http.get<ArrayBuffer>
      (`${ this.uri }${ this.svTransaccionesPath }${ this.svTransaccionesCsv }?transactionId=${ transactionRequest.transactionId }`+
                                                  `&uniqueCode=${ transactionRequest.uniqueCode }`+
                                                  `&terminalId=${ transactionRequest.terminalId }`+
                                                  `&fechaTransaccionInicio=${ transactionRequest.fechaTransaccionInicio }`+
                                                  `&fechaTransaccionFinal=${ transactionRequest.fechaTransaccionFinal }`+
                                                  `&estadoTransaccion=${ transactionRequest.estadoTransaccion }`+
                                                  `&tipoTransaccion=${ transactionRequest.tipoTransaccion }`
      , options).pipe(
        retry(2),
        tap( d => console.log('Servicio de consulta de transacciones CSV')),
        catchError(this.handleError<any>('Servicio de consulta de transacciones CSV'))
    );
  }

  obtenerToken(){
    const headers = {
      'Authorization': "Bearer "+localStorage.getItem('token')
    }
    return headers;
  }

  darFormatearFecha(fecha: Date){

    let fechaFormato = fecha.getUTCFullYear() +"/"+
                      (fecha.getUTCMonth()+1) +"/"+
                      fecha.getUTCDate() + " " +
                      fecha.getUTCHours() + ":" +
                      fecha.getUTCMinutes() + ":" +
                      fecha.getUTCSeconds();
    return fechaFormato;
  }

  private handleError<T>(operacion, resultado?:T){
    return (error: any): Observable<T> => {
      console.error(error);
      console.log(`${operacion} failed: ${error.message}`);
      return throwError(error)
    }
  }
}

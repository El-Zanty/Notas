import { TestBed } from '@angular/core/testing';
import { TerminalPasarelaService } from './terminal-pasarela.service';
import { AppConfigService } from './app-config.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';

describe('TerminalPasarelaService', () => {
  let service: TerminalPasarelaService;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;
  let controller: HttpTestingController;

  
  beforeEach(() => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
       providers: [TerminalPasarelaService,
       {provide: AppConfigService, useValue: spy}]

    });

    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;
    appConfigServiceSpy.getConfig.and.returnValue({
      "backendUrl": "https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com",
      "svRegistroTerminales": "/registro-terminales",
      "svPasarelasTerminalesPath": "/registro-terminales",
      "svPasarelasTerminalesCsvPlantilla": "/plantilla"      
    });
    service = TestBed.inject(TerminalPasarelaService);
    controller = TestBed.inject(HttpTestingController);

  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be getTerminalPasarela', () => {
    
    service.getTerminalPasarela().subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/registro-terminales")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be saveTerminalPasarela', () => {
    let terminalPasarela = {
      cuComercio: 'cu',
      nombreComercio: 'nombreComercio',
      nitComercio: 'nitComercio',
      numeroTerminal: '1234',
      usuarioCreacion: 'usuario',
      usuarioModificacion: 'usuarioModificacion',
      activo: true,
      fechaCreacion: '10/10/20',
      fechaModificacion: '10/10/20',
      nombrePasarela: 'nombrePasarela'
    }

    service.saveTerminalPasarela([terminalPasarela]).subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/registro-terminales")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be updateTerminalPasarela', () => {
    let terminalPasarela = {
      cuComercio: 'cu',
      nombreComercio: 'nombreComercio',
      nitComercio: 'nitComercio',
      numeroTerminal: '1234',
      usuarioCreacion: 'usuario',
      usuarioModificacion: 'usuarioModificacion',
      activo: true,
      fechaCreacion: '10/10/20',
      fechaModificacion: '10/10/20',
      nombrePasarela: 'nombrePasarela'
    }

    service.updateTerminalPasarela(terminalPasarela).subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/registro-terminales")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be obtenerTerminalCsv', () => {
    
    service.obtenerTerminalCsv().subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/registro-terminales/plantilla")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be exportCsv', () => {
    
    service.exportCsv().subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/registro-terminales")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  
});

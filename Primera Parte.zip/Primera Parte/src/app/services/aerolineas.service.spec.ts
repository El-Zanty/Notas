import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AerolineasService } from './aerolineas.service';
import { AppConfigService } from './app-config.service';
import { ignoreElements } from 'rxjs/operators';
import { AerolineaModel } from '../domain/models/aerolineas.model';
import { HttpErrorResponse } from '@angular/common/http';

describe('AerolineasService', () => {
  let service: AerolineasService;
  let controller: HttpTestingController;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;

  beforeEach(() => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
       providers: [AerolineasService,
       {provide: AppConfigService, useValue: spy}]
    });

    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;
    appConfigServiceSpy.getConfig.and.returnValue({
      backendUrl: 'urlTest',
      svAerolineasPath: '/test',
      endpointCSV: 'csv'
    });
    service = TestBed.inject(AerolineasService);
    controller = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();

  });

  it('should obtenerAerolineas', () => {
    let aerolineasActuales: AerolineaModel[] | undefined;
    service.obtenerAerolineas().subscribe(
      (aerolineas) => {
        aerolineasActuales = aerolineas;
      }
    );
    
    const request = controller.expectOne('urlTest/test');

    // Answer the request so the Observable emits a value.
    const aerolinea = { id:1234,
      name: 'aerolinea',
      nacional: 1,
      uniqueCode: 123 }
    request.flush({aerolinea});

    // Now verify emitted valued.
    expect(aerolineasActuales).toEqual( [aerolinea]);
      })

      it('should obtenerAerolineas return null', () => {
        let aerolineasActuales: any | undefined;
        service.obtenerAerolineas().subscribe(
          (aerolineas) => {
            aerolineasActuales = aerolineas;
          }
        );
        
        const request = controller.expectOne('urlTest/test');
    
        // Answer the request so the Observable emits a value.
     
        request.flush(null);
    
        // Now verify emitted valued.
        expect(aerolineasActuales).toEqual([]);
          })

  it('should obtenerAerolinea', () => {
    let aerolineasActuales: AerolineaModel | undefined;
    service.obtenerAerolinea(1).subscribe(
      (aerolineas) => {
        aerolineasActuales = aerolineas;
      }
    );
    const request = controller.expectOne('urlTest/test1');

    // Answer the request so the Observable emits a value.
    const aerolinea = { id:1234,
      name: 'aerolinea',
      nacional: 1,
      uniqueCode: 123 }
    request.flush(aerolinea);

    // Now verify emitted valued.
    expect(aerolineasActuales).toEqual( aerolinea);
  })

  it('should editarAerolinea', () => {
    let editarAerolinea: AerolineaModel | undefined;
    service.editarAerolinea(editarAerolinea).subscribe(
      (aerolineas: AerolineaModel) => {
        editarAerolinea = aerolineas;
      }
    );
    const request = controller.expectOne('urlTest/test');

    // Answer the request so the Observable emits a value.
    const aerolinea = { id:1234,
      name: 'aerolinea',
      nacional: 1,
      uniqueCode: 123 }
    request.flush(aerolinea);

    // Now verify emitted valued.
    expect(editarAerolinea).toEqual( aerolinea);
  })

  it('should exportCsv', () => {
    let editarAerolinea: AerolineaModel | undefined;
    service.exportCsv().subscribe(
      (aerolineas: any) => {
        editarAerolinea = aerolineas;
      }
    );
    const request = controller.expectOne('');

    // Answer the request so the Observable emits a value.
    const aerolinea = { id:1234,
      name: 'aerolinea',
      nacional: 1,
      uniqueCode: 123 }
    request.flush(aerolinea);

    // Now verify emitted valued.
    expect(editarAerolinea).toEqual( aerolinea);
  })

  it('should exportCsv with 500 error', () => {
    let actualError: HttpErrorResponse | undefined;
    service.exportCsv().subscribe(
      () => {
        fail('next handler must not be called');
      },
      (error) => {
        actualError = error;
      },
      () => {
        fail('complete handler must not be called');
      }
    );
    const status = 500;
const statusText = 'Internal Server Error';
const errorEvent = new ErrorEvent('API error');

controller.expectOne('').error(
  errorEvent,
  { status, statusText }
);
  })
  
 
});
 
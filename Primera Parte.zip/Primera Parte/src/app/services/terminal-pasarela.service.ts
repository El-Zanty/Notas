import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry, tap } from 'rxjs/operators';
import { TerminalPasarela } from '../domain/models/terminal-pasarela.model';
import { AppConfigService } from './app-config.service';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class TerminalPasarelaService {

  // pasarela service endpoint
  private endpoint: string;
  private endpointCSV: string;
  private endpointTemplate: string;

  constructor(private http: HttpClient, private config: AppConfigService) {
this.getProperties();
   }
 

  getProperties(): void {
    const { svRegistroTerminales, backendUrl, svPasarelasTerminalesCsvPlantilla, svPasarelasTerminalesPath} = this.config.getConfig();
    this.endpoint = backendUrl + svRegistroTerminales;
    this.endpointTemplate = backendUrl + svPasarelasTerminalesPath + svPasarelasTerminalesCsvPlantilla;
    this.endpointCSV = backendUrl + svPasarelasTerminalesPath;
  }

  // error handler
  private handleError(error: HttpErrorResponse): any {

    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred: ', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }

    return throwError(error);
  }

  /// get token function //TODO: provide general function (service) and validate localStorage token not empty
  private getToken() {

    const headers = {
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    };

    return headers;
  }

  getTerminalPasarela(): Observable<any> {

    const headers = this.getToken();

    return this.http.get<TerminalPasarela>(this.endpoint, {headers}).pipe(
      catchError(this.handleError)
    );
  };

  // create a new pasarela
  saveTerminalPasarela(newTerminalPasarela: TerminalPasarela[]): Observable<any> {
    const headers = this.getToken();
    return this.http.post(this.endpoint, newTerminalPasarela, {headers, responseType: 'text'}  ).pipe(
      catchError( e => {
        console.log(e);
        Swal.fire({
          icon: 'error',
          title: 'Error al crear pasarela',
          text: e.message
        })
        return this.handleError(e);
      })
    );
  }

  // update a pasarela
  updateTerminalPasarela(editedTerminalPasarela: TerminalPasarela): Observable<any> {

    const headers = this.getToken();

    return this.http.put<TerminalPasarela>(this.endpoint, editedTerminalPasarela, {headers}).pipe(
      catchError(this.handleError)
    );
  }


  obtenerTerminalCsv(): Observable<ArrayBuffer> {
    const headers = this.getToken();
    const options = { headers, responseType: 'text' as any };
    return this.http.get<ArrayBuffer>
      (`${ this.endpointTemplate}`
      , options).pipe(
        retry(2),
        tap( d => console.log('Servicio de consulta de transacciones CSV')),
        catchError(this.handleErrorCsv<any>('Servicio de consulta de transacciones CSV'))
    );
  }
  private handleErrorCsv<T>(operacion, resultado?:T){
    return (error: any): Observable<T> => {
      console.error(error);
      console.log(`${operacion} failed: ${error.message}`);
      return throwError(error)
    }
  }

  public exportCsv(): Observable<any> {
    const headers = this.getToken();

    return this.http.get<TerminalPasarela>(`${this.endpointCSV}`, {headers}).pipe(
      catchError(this.handleError)
    );
  }

}

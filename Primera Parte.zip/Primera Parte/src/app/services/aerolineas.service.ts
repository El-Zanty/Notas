import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AerolineaModel } from '../domain/models/aerolineas.model';
import { AppConfigService } from './app-config.service';

@Injectable({
  providedIn: 'root'
})
export class AerolineasService  {

  private url;
  private svAerolineasPath;
  private endpointCSV;

  constructor(  private http: HttpClient,
                private config: AppConfigService ) {

                  const {backendUrl, svAerolineasPath} = config.getConfig();
                  this.url = backendUrl;
                  this.svAerolineasPath = svAerolineasPath;
                  this.endpointCSV = '';

                }

  obtenerAerolineas(){
    const headers = this.obtenerToken();
    console.log(`${ this.url }${ this.svAerolineasPath }`,{headers})
    return this.http.get(`${ this.url }${ this.svAerolineasPath }`,{headers})
    .pipe(
      map( this.crearArreglo )

    )
  }

  obtenerAerolinea(id:number): Observable<AerolineaModel>{
    const headers = this.obtenerToken();
    return this.http.get<AerolineaModel>(`${ this.url }${ this.svAerolineasPath }${id}`,{headers})
  }

  editarAerolinea( aerolinea: AerolineaModel){
    console.log(aerolinea);
    const headers = this.obtenerToken();
    return this.http.put(`${ this.url }${ this.svAerolineasPath }`,aerolinea ,{headers});
  }


  private crearArreglo( aerolineasObj: object){

    const aerolineas: AerolineaModel[] = [];

    if( aerolineasObj === null ) { return []; }

    Object.keys( aerolineasObj ).forEach( key => {
      const aerolinea: AerolineaModel = aerolineasObj[key];
      aerolineas.push( aerolinea );
    })

    return aerolineas;
  }

  obtenerToken(){
    const headers = {
      'Authorization': "Bearer "+localStorage.getItem('token')
    }
    return headers;
  }

  public exportCsv(): Observable<any> {
    const headers = this.obtenerToken();

    return this.http.get<any>(`${this.endpointCSV}`, {headers}).pipe(
      catchError(this.handleError)
    );
  }
  // error handler
  private handleError(error: HttpErrorResponse): any {

    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred: ', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }

    return throwError('Something bad happened; please try again later.');
  }
}

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed, flush, fakeAsync, tick } from '@angular/core/testing';

import { AppConfigService } from './app-config.service';
import promisedData from '../../assets/config/config.json';

describe('AppConfigService', () => {
  let service: AppConfigService;    
  let controller: HttpTestingController;
 

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AppConfigService]
    });
    service = TestBed.inject(AppConfigService);
    controller = TestBed.inject(HttpTestingController);
    
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should loadConfig', fakeAsync(() => {
    let data:any;   

    service.loadConfig().then(value => {     
      data = value; 
      expect(service.getConfig()).toEqual(promisedData);
    });

    const request = controller.expectOne('./assets/config/config.json');
    request.flush(promisedData);    
   tick(3000);
   expect(service.getConfig()).toEqual(promisedData);
    
    }));

    it('should reject loadConfig', fakeAsync(()=>  {
      
     
      service.loadConfig().then(value => {     
      
      });

      const request = controller.expectOne('./assets/config/config.json');
    request.flush(new Error('no'));   

        expectAsync(service.loadConfig())
        .toBeRejectedWith('no');
      
    }));     
});

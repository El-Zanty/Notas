import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from '../services/app-config.service';

import { AuthGuard } from './auth.guard';

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;

  beforeEach(() => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
      RouterTestingModule],
        providers: [AuthGuard,
        {provide: AppConfigService, useValue: spy}]
    });
    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;
    appConfigServiceSpy.getConfig.and.returnValue({});
    guard = TestBed.inject(AuthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});

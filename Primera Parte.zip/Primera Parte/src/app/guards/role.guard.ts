import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import swal from 'sweetalert2';
import { AppConfigService } from '../services/app-config.service';


@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  roles: any;

  constructor(private auth: AuthService,
              private route: Router,
              private config: AppConfigService){
                this.roles = config.getConfig();
              }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      let ruta = route.routeConfig.path as string;
      let role = '';

      if( ruta.includes('aerolineas')) {
        role = this.roles.aerolineasConsulta;
      } else if(ruta.includes('aerolineas/form')) {
        role = this.roles.aerolineasEdicion;
      } else if( ruta.includes('transacciones')) {
        role = this.roles.transaccionesGet;
      } else if ( ruta === 'terminales') {
        role = this.roles.terminalesConsulta;
      } else if (ruta === 'terminales/crear') {
        role = this.roles.terminalesCreacion;
      } else if (ruta === 'terminales/editar') {
        role = this.roles.terminalesEdicion;
      } else if (ruta === 'terminales/desactivar') {
        role = this.roles.terminalesDesactivacion;
      } else if (ruta === 'pasarelas') {
        role = this.roles.pasarelasConsulta;
      } else if (ruta === 'detallePasarelas') {
        role = this.roles.asociacionTerminalesConsulta;
      }




      if(this.auth.tieneRol(role)){
        return true;
      }
      swal.fire({
        icon: 'error',
        title: 'Acceso denegado',
        text: 'No tienes acceso a esta ruta'
      })
      this.route.navigate(['/home']);
    return false;
  }

}

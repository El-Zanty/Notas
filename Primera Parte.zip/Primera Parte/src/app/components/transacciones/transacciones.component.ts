import { Component, OnInit } from '@angular/core';
import { Transaction, TransactionRequest, TransactionResponse } from 'src/app/domain/models/transacciones.model';
import { TransaccionesService } from 'src/app/services/transacciones.service';
import { saveAs } from 'file-saver';
import Swal from 'sweetalert2';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AppConfigService } from 'src/app/services/app-config.service';

@Component({
  selector: 'app-transacciones',
  templateUrl: './transacciones.component.html'
})
export class TransaccionesComponent implements OnInit {

  buttonType: string;
  importCsv: number;
  fechaInicio: string;
  fechaFinal: string;
  tiempoInicio: string;
  tiempoFin: string;
  rangoFechaValida: boolean;
  transaction: TransactionResponse = new TransactionResponse();
  transaccionParametrosBusqueda: TransactionRequest = new TransactionRequest();
  transacciones: Transaction[] = [];
  paginador: any;
  page: number;
  ruta: string = '/transacciones/page';
  codesDescription: any;

  formularioTransaccion = new FormGroup({
    validacionTransactionId: new FormControl(),
    validacionPasarela: new FormControl(),
    validacionAuthorizationCode: new FormControl(),
    validacionTerminal: new FormControl(),
    validacionCU: new FormControl(),
    validacionFechaInicio: new FormControl(),
    validacionTiempoInicio: new FormControl(),
    validacionFechaFinal: new FormControl(),
    validacionTiempoFinal: new FormControl(),
    validacionEstado: new FormControl(),
    validacionTipoTransaccion: new FormControl()
  });

  constructor(private servicioTransacciones: TransaccionesService,
  private activateRoute: ActivatedRoute,
  private config: AppConfigService ) {
    this.codesDescription = config.getCodesDescription();
   }

  ngOnInit(): void {
    this.activateRoute.paramMap.subscribe ( params => {
      if(this.page !== undefined){
        this.page = params.get('page')?+params.get('page'):null;
        this.atLeastOneValidator('find');
      } else {
        this.page = 0;
      }
    })
  }

  functionXOR(a,b,c,d): boolean {
    //return ( a || b ) && !( a && b );
    return (!a && d) || (c && !d) || (b && !c) || (a && !b);
  }

  atLeastOneValidator(buttonType) {

   let controls = this.formularioTransaccion.controls;
   if (controls) {
     let selectedValue = Object.keys(controls).findIndex(key => controls[key].value);
     if (selectedValue === -1) {
       Swal.fire({
         icon: 'error',
         title: 'parametros de busqueda insuficientes',
         text: 'Al menos un campo debe ser seleccionado',
       })
     } else if(this.functionXOR(controls['validacionFechaInicio'].value, controls['validacionTiempoInicio'].value,
                                controls['validacionFechaFinal'].value, controls['validacionTiempoFinal'].value)) {
       Swal.fire({
         icon: 'error',
         title: 'rango de fechas incorrecto',
         text: 'Se deben diligenciar todos los campos del filtro',
       })
     }
     else {
       this.obtenerTransacciones(buttonType);
     }
   };

 }

  obtenerTransacciones(buttonType){
    this.dateToStringMap();

    if(buttonType==="find"){
      Swal.fire({
        allowOutsideClick: false,
        icon: 'info',
        text: 'Realizando la búsqueda..'
      });
      Swal.showLoading();

      this.servicioTransacciones.obtenerTransacciones(this.transaccionParametrosBusqueda,this.page).subscribe(
        resp => {
          Swal.close()
          this.transacciones = [];
          this.paginador = resp;
          resp.content.forEach(transaccion =>{
            this.transacciones.push(transaccion);
          })
        },
        err => {
          Swal.close()
          console.log("Servicio de consulta de transacciones", err)
          if(err.status===404)
            Swal.fire({icon: 'error', title: 'Error', text: err.error.details});
          else
            Swal.fire({icon: 'error', title: 'Error', text: "Error en el servicio de consulta de transacciones"});
        }
      )
    }else if(buttonType==="csv"){
      Swal.fire({
        allowOutsideClick: false,
        icon: 'info',
        text: 'Obteniendo el archivo CSV...'
      });
      Swal.showLoading();

      this.servicioTransacciones.obtenerTransaccionesCsv(this.transaccionParametrosBusqueda)
      .subscribe((data: any) => {
          Swal.close()
          const blob = new Blob([data], { type: 'application/octet-stream' });
          const fileName = 'File.csv';
          saveAs(blob, fileName);
         },

         err => {
            Swal.close()
            console.log("Servicio de consulta de transacciones CSV", err);
            Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo el archivo CSV"});
          }
      )
    }
  }

  dateToStringMap(){
    if(this.fechaInicio && this.tiempoInicio && this.fechaFinal && this.tiempoFin){
      this.transaccionParametrosBusqueda.fechaTransaccionInicio = `${ this.fechaInicio } ${ this.tiempoInicio }:00`;
      this.transaccionParametrosBusqueda.fechaTransaccionFinal = `${ this.fechaFinal } ${ this.tiempoFin }:00`
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { AerolineaModel } from 'src/app/domain/models/aerolineas.model';
import { AerolineasService } from 'src/app/services/aerolineas.service';
import { saveAs } from 'file-saver';
import Papa from 'papaparse';
import { AppConfigService } from 'src/app/services/app-config.service';
import { AuthService } from 'src/app/services/auth.service';

import Swal from 'sweetalert2';

@Component({
  selector: 'app-obtener-aerolineas',
  templateUrl: './obtener-aerolineas.component.html'
})
export class ObtenerAerolineasComponent implements OnInit {

  aerolineas: AerolineaModel[] = [];
  isAerolineasEdicion: boolean;

  constructor(private aerolineasService: AerolineasService,
  private config: AppConfigService,
  private auth: AuthService) {
    const { aerolineasEdicion } = config.getConfig();
    this.isAerolineasEdicion = auth.tieneRol(aerolineasEdicion);
   }

  ngOnInit(): void {
    Swal.showLoading();
    this.aerolineasService.obtenerAerolineas()
    .subscribe( resp => {
      Swal.close()
      this.aerolineas = resp
    },

    err => {
       Swal.close()
       console.log("error obteniendo la información", err);
       Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo la información"});
     });
  }
  exportarCsv():void {
    this.aerolineasService.obtenerAerolineas()
    .subscribe((data: any) => {
      var csv = Papa.unparse(data);
      const blob = new Blob([csv], { type: 'application/octet-stream' });
      const fileName = 'Aerolineas.csv';
      saveAs(blob, fileName);
    })
  }
}

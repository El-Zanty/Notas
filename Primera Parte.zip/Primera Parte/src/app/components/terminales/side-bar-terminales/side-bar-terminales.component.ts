import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConsultaTerminalResponse } from 'src/app/domain/models/sv-terminal-generica-response-dto.model';
import { AppConfigService } from 'src/app/services/app-config.service';
import { AuthService } from 'src/app/services/auth.service';
import { SvTerminalGenericaService } from 'src/app/services/sv-terminal-generica.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-side-bar-terminales',
  templateUrl: './side-bar-terminales.component.html'
})
export class SideBarTerminalesComponent implements OnInit {

  numeroTerminal: string;
  tieneAcceso: boolean;
  accesoCreacion: string;
  accesoEdicion: string;
  accesoDesactivacion: string;
  accesoConsulta: string;

  constructor(private servicioConsulta: SvTerminalGenericaService,
              private router: Router,
              private auth: AuthService,
              private config: AppConfigService) {
                const { terminalesCreacion,
                        terminalesEdicion,
                        terminalesDesactivacion,
                        terminalesConsulta
                        } = config.getConfig();
                this.accesoCreacion = terminalesCreacion;
                this.accesoEdicion = terminalesEdicion;
                this.accesoDesactivacion = terminalesDesactivacion;
                this.accesoConsulta = terminalesConsulta;
               }

  ngOnInit(): void {
  }

  buscarTerminal(){
    this.router.navigate(['/terminales'], { queryParams: { terminalId: this.numeroTerminal } });
  }

  tieneRol(accion:string):boolean {
    return this.auth.tieneRol(accion);
  }

}

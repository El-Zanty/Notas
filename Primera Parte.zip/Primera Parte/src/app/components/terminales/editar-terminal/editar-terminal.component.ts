import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TerminalGenericaRequest } from 'src/app/domain/models/sv-terminal-generica-request-dto.model';
import { ConsultaTerminalResponse } from 'src/app/domain/models/sv-terminal-generica-response-dto.model';
import { SvTerminalGenericaService } from 'src/app/services/sv-terminal-generica.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-terminal',
  templateUrl: './editar-terminal.component.html'
})
export class EditarTerminalComponent implements OnInit {
  terminalRequest: TerminalGenericaRequest = new TerminalGenericaRequest();
  listaServicios: any[] = [];
  terminal: ConsultaTerminalResponse = null;

  constructor(private svTerminalGenerica: SvTerminalGenericaService,
              private route: ActivatedRoute) {
              }

  ngOnInit(): void {
    this.listaServicios = this.poblarListaServicios();
  }

  editarTerminal( form: NgForm ){
    console.log(form);
    this.listaServicios.forEach((servicios) => {
      if (servicios.enabled) {
        let numService = servicios.nombre;
        this.terminalRequest.funcionalidadesPrincipales.push(numService);
      }
    });

    this.mostrarConfimacion().then((respuesta: boolean) =>{
      Swal.fire({
        allowOutsideClick: false,
        icon: 'info',
        text: 'Editando terminal...',
      });
      Swal.showLoading();
      if(respuesta){
        this.svTerminalGenerica.editarTerminal( this.terminalRequest )
          .subscribe( resp => {
            console.log(resp);
            Swal.fire(
              'Edición exitosa!',
              'Se ha editado con éxito la terminal con número: '+ this.terminalRequest.terminal,
              'success'
            );
        }, (err) => {
          console.log(err.name);
          Swal.fire({
            icon: 'error',
            title: 'Error al editar la terminal',
            text: err.error.details.substring(err.error.details.indexOf("mensaje")).replaceAll(/["{}]/g,''),
          });
        });
      }else{
        Swal.fire({
          icon: 'info',
          title: 'No se guardaron cambios',
          text: 'No se han guardado los cambios',
        })
      }
    }
  );
  }

  private poblarListaServicios() {
    const listaServicios: any[] = [
      { nombre: 'DCC VISA', codigo: '50170005', enabled: false },
      { nombre: 'DCC MC', codigo: '50170008', enabled: false },
      { nombre: '3D Secure', codigo: '50170009', enabled: false }
    ];
    return listaServicios;
  }


  private ListaServicios(servicios: string[]) {
    const listaServicios: any[] = [
      { nombre: 'Comercio tradicional',             codigo: '50170000', enabled: false },
      { nombre: 'Multicomercio tradicional',        codigo: '50170001', enabled: false },
      { nombre: 'Multicomercio agencias',           codigo: '50170002', enabled: false },
      { nombre: 'Multicomercio servicios públicos', codigo: '50170003', enabled: false },
      { nombre: 'DCC VISA',                         codigo: '50170005', enabled: false },
      { nombre: 'DCC MC',                           codigo: '50170008', enabled: false },
      { nombre: '3D SECURE',                        codigo: '50170009', enabled: false },
      { nombre: 'API',                              codigo: '50170010', enabled: false },
      { nombre: 'Link de pagos',                    codigo: '50170011', enabled: false },
      { nombre: 'Botón de pago',                    codigo: '50170012', enabled: false },
      { nombre: 'PAGO',                             codigo: '50170013', enabled: false },
      { nombre: 'Web de pagos',                     codigo: '50170014', enabled: false },
      { nombre: 'Pago recurrente',                  codigo: '50170015', enabled: false },
    ];
    listaServicios.forEach((servicioList, index) => {
      servicios.forEach(servicio =>{
        if(servicio==servicioList.nombre){
          listaServicios[index].enabled = true
          console.log(listaServicios[index].enabled)
        }
      })
    })
    return listaServicios;
  }

  private mostrarConfimacion() : Promise<boolean>{
    return Swal.fire({
      title: '¿Desea guardar los cambios realizados?',
      showDenyButton: true,
      confirmButtonText: `Si`,
      denyButtonText: `No`,
    }).then((result) => {
      if (result.isConfirmed) {
        return true;
      } else if (result.isDenied) {
        return false;
      }
    })
  }
}

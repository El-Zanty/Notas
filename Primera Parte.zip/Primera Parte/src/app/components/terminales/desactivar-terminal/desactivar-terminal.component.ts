import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DesactivarTerminalRequest } from 'src/app/domain/models/sv-terminal-desactivar-request.model';
import { SvTerminalGenericaService } from 'src/app/services/sv-terminal-generica.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-desactivar-terminal',
  templateUrl: './desactivar-terminal.component.html'
})
export class DesactivarTerminalComponent implements OnInit {

  desactivarTerminalRequest: DesactivarTerminalRequest = new DesactivarTerminalRequest();

  constructor( private svTerminales : SvTerminalGenericaService ) { }

  ngOnInit(): void {
  }

  desactivarTerminal( form: NgForm ){

    console.log(form)
    if ( form.invalid ){
      return;
    }

    this.mostrarConfimacion().then((respuesta: boolean) =>{
      if(respuesta){
        Swal.fire({
          allowOutsideClick: false,
          icon: 'info',
          text: 'Desactivando terminal...',
        });
        Swal.showLoading();
        this.svTerminales.desactivarTerminal( this.desactivarTerminalRequest )
          .subscribe( resp => {
            console.log(resp);
            Swal.fire({
              icon: 'info',
              title: 'Terminal desactivada',
              text: `Terminal número ${ this.desactivarTerminalRequest.terminal } ha sido desactivada`,
            })
        }, (err) => {
          console.log(err.name);
          Swal.fire({
            icon: 'error',
            title: 'Error al editar la terminal',
            text: err.error.details.substring(err.error.details.indexOf("mensaje")).replaceAll(/["{}]/g,''),
          });
        });
      }else{
        Swal.fire({
          icon: 'info',
          title: 'No se desactivó la terminal',
          text: 'No se desactivó la terminal',
        })
      }
    });
  }

  private mostrarConfimacion() : Promise<boolean>{
    return Swal.fire({
      title: `¿Desea desactivar la terminal número ${ this.desactivarTerminalRequest.terminal } ?`,
      showDenyButton: true,
      confirmButtonText: `Si`,
      denyButtonText: `No`,
    }).then((result) => {
      if (result.isConfirmed) {
        return true;
      } else if (result.isDenied) {
        return false;
      }
    })
  }

}

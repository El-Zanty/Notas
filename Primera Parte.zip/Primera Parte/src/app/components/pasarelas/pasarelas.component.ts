import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { Pasarela } from '../../domain/models/pasarela.model';
import {PasarelaService } from '../../services/pasarela.service';
import { saveAs } from 'file-saver';
import Papa from 'papaparse';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pasarelas',
  templateUrl: './pasarelas.component.html',
  styleUrls: ['./pasarelas.component.css']
})
export class PasarelasComponent implements OnInit {

  @Input() editablePasarela: Pasarela = null;
  @Input() createdPasarela: Pasarela = null;

  pasarelas: Pasarela[] = [];

  constructor(private router: Router, private pasarelaService: PasarelaService, private modalService: NgbModal) { }

  ngOnInit(): void {
    Swal.showLoading();
    this.getPasarelas();
  }

  // get all pasarelas from the pasarela service
  getPasarelas(): void {

    // call the pasarela service
    this.pasarelaService.getPasarelas()
    .subscribe( resp => {
      Swal.close();
      this.pasarelas = resp
    },

    err => {
       Swal.close()
       console.log("error obteniendo la información", err);
       Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo la información"});
     });

  }

  exportarCsv():void {
    this.pasarelaService.getPasarelas()
    .subscribe((data: any) => {
      var csv = Papa.unparse(data);
      const blob = new Blob([csv], { type: 'application/octet-stream' });
      const fileName = 'Pasarelas.csv';
      saveAs(blob, fileName);
    })
  }

}

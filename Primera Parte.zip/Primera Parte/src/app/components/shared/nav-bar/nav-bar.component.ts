import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfigService } from 'src/app/services/app-config.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  tokenDetails;
  accesoTransaccion: string;
  accesoAerolinea: string;
  accesoPasarelas: string;
  accesoAsociacionTerminales: string;


  constructor(private auth: AuthService,
              private router: Router,
              private config: AppConfigService) {

                const { transaccionesGet,
                        aerolineasConsulta,
                        pasarelasConsulta,
                        asociacionTerminalesConsulta
                        } = config.getConfig();
                this.accesoTransaccion = transaccionesGet;
                this.accesoAerolinea = aerolineasConsulta;
                this.accesoPasarelas = pasarelasConsulta;
                this.accesoAsociacionTerminales = asociacionTerminalesConsulta;
               }

  ngOnInit(): void {
    this.tokenDetails = this.auth.traducirToken();
  }

  salir(){
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }

  tieneRol(accion:string):boolean {
    return this.auth.tieneRol(accion);
  }

}

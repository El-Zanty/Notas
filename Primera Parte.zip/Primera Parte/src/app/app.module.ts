import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { RegistroComponent } from './components/registro/registro.component';
import { LoginComponent } from './components/login/login.component';
import { NavBarComponent } from './components/shared/nav-bar/nav-bar.component';
import { SideBarComponent } from './components/shared/side-bar/side-bar.component';
import { ObtenerAerolineasComponent } from './components/admin-aerolineas/obtener-aerolineas/obtener-aerolineas.component';
import { EditarAerolineaComponent } from './components/admin-aerolineas/editar-aerolinea/editar-aerolinea.component';
import { TransaccionesComponent } from './components/transacciones/transacciones.component';
import { LogAuditoriaComponent } from './components/log-auditoria/log-auditoria.component';
import { ConsultaTerminalesComponent } from './components/terminales/consulta-terminales/consulta-terminales.component';
import { CrearTerminalComponent } from './components/terminales/crear-terminal/crear-terminal.component';
import { EditarTerminalComponent } from './components/terminales/editar-terminal/editar-terminal.component';
import { AppConfigService } from './services/app-config.service';
import { DesactivarTerminalComponent } from './components/terminales/desactivar-terminal/desactivar-terminal.component';
import { SideBarTerminalesComponent } from './components/terminales/side-bar-terminales/side-bar-terminales.component';
import { PasarelasComponent } from './components/pasarelas/pasarelas.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DetallePasarelasComponent } from './components/detalle-pasarelas/detalle-pasarelas.component';
import { PaginadorComponent } from './components/paginador/paginador.component';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { MomentModule } from 'angular2-moment';
export function initConfig(appConfig: AppConfigService) {
  appConfig.loadCodesDescription();
  return () => appConfig.loadConfig();
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegistroComponent,
    LoginComponent,
    NavBarComponent,
    SideBarComponent,
    ObtenerAerolineasComponent,
    EditarAerolineaComponent,
    TransaccionesComponent,
    LogAuditoriaComponent,
    ConsultaTerminalesComponent,
    CrearTerminalComponent,
    EditarTerminalComponent,
    DesactivarTerminalComponent,
    SideBarTerminalesComponent,
    PasarelasComponent,
    DetallePasarelasComponent,
    PaginadorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    NgIdleKeepaliveModule.forRoot(),
    MomentModule
  ],
  providers: [{
    provide: APP_INITIALIZER,
    useFactory: initConfig,
    deps: [AppConfigService],
    multi: true,
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }

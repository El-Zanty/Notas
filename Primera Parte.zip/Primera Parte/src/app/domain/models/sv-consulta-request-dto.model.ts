export class SVConsultaRequestDTO{
  constructor(
    public operation: String,
    public code: String
  ){}
}
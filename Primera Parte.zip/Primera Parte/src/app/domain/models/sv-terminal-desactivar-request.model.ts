export class DesactivarTerminalRequest{
  comercio : string ;
  terminal  : string ;
  pasarela: string;
}

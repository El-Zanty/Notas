export class ServicioTerminalModel {
  constructor(
    public numService: String,
    public fechaInicio: String,
    public fechaFin: String,//pendiente propina y referencia
  ){}
}
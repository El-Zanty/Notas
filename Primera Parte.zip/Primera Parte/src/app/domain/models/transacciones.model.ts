export class TransactionRequest{
  transactionId: string = "";
  uniqueCode: string = "";
  terminalId: string = "";
  fechaTransaccionInicio: string = "";
  fechaTransaccionFinal: string = "";
  estadoTransaccion: string = "";
  tipoTransaccion: string = "";
  pageNumber: string = "0";
  pageSize:           string = "30";
  pasarela: string= "";
  authorizationCode: string="";
}

export class TransactionResponse{
  content:            Transaction[];
  size:               string;
  totalElements:      string;
  totalPages:         string;
  number:             string;
}

export class Transaction{
  transactionId:      string;
  transactionDate:    string;
  transactionType:    string;
  transactionType2:   string;
  transactionTaxType: string;
  pasarela:           string;
  uniqueCode:         string;
  terminalId:         string;
  purchaseAmount:     string;
  ivaTax:             string;
  installmentsNumber: string;
  references:         References[];
  currencyCode:       string;
  ipAddress:          string;
  airporTax:          string;
  airlineCode:        string;
  tip:                string;
  iacTax:             string;
  brandId:            string;
  cardAccountTypeId:  string;
  bin:                string;
  lastDigits:         string;
  stateCode:          string;
  authorizationCode:  string;
  mitState:           string;
  transactionState:   string;
  additionalData:     AdditionalData;
  transactionObjectRequest: string;
}

export class AdditionalData{
  isoRequest:               string;
  isoResponse:              string;
  transactionObjectRequest: string;
  transactionObjectResponse:string;
  isoRequestDate:           string;
  isoResponseDate:          string;
  originalCaptureDate:      string;

}

export class References{
  referenceKey:         string;
  referenceDescription: string;
}

export class TerminalPasarela {
  cuComercio: string = '';
  nombreComercio: string = '';
  nitComercio: string = '';  
  numeroTerminal: string = '';
  usuarioCreacion: string = '';
  usuarioModificacion: string = '';
  activo: boolean = true;
  fechaCreacion: string = '';
  fechaModificacion: string = '';
  nombrePasarela: string = '';
}

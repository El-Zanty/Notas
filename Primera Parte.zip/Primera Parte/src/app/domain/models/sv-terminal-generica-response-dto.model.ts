export class TerminalGenericaResponse {
  constructor(
    public codigoRespuesta: String,
    public descripcion: String,
    public terminalesCreadas: string[]
  ){}
}

export class ConsultaTerminalResponse{
  terminalId          : string;
  uniqueCode          : string;
  indicadorIca        : string;
  indicadorIva        : string;
  indicadorPropina    : number;
  terminalState       : string;
  indicadorReferencia : number;
  servicios           : string[];
}

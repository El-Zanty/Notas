export class Pasarela {
    activo: boolean;
    fechaCreacion: string;
    usuario: string;
    correoElectronico: string;
    // terminales: Terminal[]?: no corresponde al modelo existente
}

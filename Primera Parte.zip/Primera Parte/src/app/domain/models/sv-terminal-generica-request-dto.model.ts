export class TerminalGenericaRequest{
  public codigoUnico: String;
  public cantidadTerminales: number = 1;
  public tipoComercio: string = 'NORMAL';
  public funcionalidadesPrincipales: string[] = [];
  public terminal : string = '';
  public pasarela: string = '';
}

export class Terminal {
  public cantidadTerminales: number = 1;
  public idTerminales: string[] = [];
  public dueno: String = '50145001';
  public tipoDispositivo: String = 'TRMT0004';
  public tipoComunicacion: String = '50125009';
  public tipoIntegracionTEF: String = '50105000';
  public marcaDispositivo: String = "";
  public indicadorIac: number = 0;
  public indicadorIva: number = 0;
  public idServicio: String[] = [];
  public indicadorPropina: Number = 0;
  public indicadorDeReferencia: string;
  public indicadorCvv2: number = 0;
  public direccionDeInstalacion: DireccionInstalacion = new DireccionInstalacion();
  public estadoTerminal: String = 'TRMS0001';
  public razonEstado: string = '';
  public serial: String = "";
  public sello: String = "";
  public numeroCaja: String = "";
  public codigoArrendamiento: String = '50040009';
  public fechaRetiroProgramado: String = "";
  public observaciones: String = "";
}

export class DireccionInstalacion {
  public pais: String = '170';
  public direccionNumero: String = 'Calle 127 C';
  public apartamentoOficina: string = '';
  public codigoPostal: string = '';
  public codigoRegion: String = '11001';
  public latitud: Number = 0;
  public longitud: Number = 0;
}

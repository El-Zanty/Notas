import { Usecase } from "../../base/use-case";
import { AerolineaModel } from "../../models/aerolineas.model";

export class aeroliniasUseCase implements Usecase<{},AerolineaModel >
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';

import Swal from 'sweetalert2';
import { AppConfigService } from './services/app-config.service';
import { AppService } from './services/app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  title = 'snp-portal-frontend';

  constructor(private idle: Idle,
     private keepalive: Keepalive,
     private router: Router,
     private appService: AppService,
     private config: AppConfigService) {
      idle.setIdle(1);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      idle.setTimeout(config.getConfig().timeOut);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

      idle.onIdleEnd.subscribe(() => {
        this.idleState = 'No longer idle.'
        this.reset();
      });

      idle.onTimeout.subscribe(() => {
        this.idleState = 'Timed out!';
        this.timedOut = true;
        console.log(this.idleState);
        Swal.fire({
          icon: 'info',
          title: 'Sesión expirada',
          text: 'la sesión se cerro por inactividad'
        })
        this.router.navigateByUrl('/login');
      });

      idle.onIdleStart.subscribe(() => {
          this.idleState = 'You\'ve gone idle!'
      });

      idle.onTimeoutWarning.subscribe((countdown) => {
        this.idleState = 'You will time out in ' + countdown + ' seconds!'
      });

      // sets the ping interval to 15 seconds
      keepalive.interval(15);

      keepalive.onPing.subscribe(() => this.lastPing = new Date());

      this.appService.getUserLoggedIn().subscribe(userLoggedIn => {
      if (userLoggedIn) {
        idle.watch()
        this.timedOut = false;
      } else {
        idle.stop();
      }
    })
    }

    reset() {
   this.idle.watch();
   this.idleState = 'Started.';
   this.timedOut = false;
 }
}

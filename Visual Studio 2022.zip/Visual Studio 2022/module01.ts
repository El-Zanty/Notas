function addNumbers(x:number, y:number) {
    return x + y;
  }
  console.log(addNumbers(3, 6));
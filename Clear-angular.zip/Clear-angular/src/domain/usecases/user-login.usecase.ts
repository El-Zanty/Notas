import {Observable} from 'rxjs';
import {Usecase} from '../base/use-case';
import {UserModel} from '../models/user.model';
import { UserRepository } from '@domain/repository/user.repository';

export class UserLoginUseCase implements Usecase<{ username: string; password: string }, UserModel>{
    constructor (private userRepository: UserRepository){}
    execute(param: { username: string; password: string; }, ): Observable<UserModel> {
        return this.userRepository.login(param); }
}
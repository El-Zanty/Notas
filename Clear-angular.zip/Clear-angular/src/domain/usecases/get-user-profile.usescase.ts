import {Observable} from 'rxjs';
import {Usecase} from '../base/use-case';
import {UserModel} from '../models/user.model';
import { UserRepository } from '@domain/repository/user.repository';

export class GetUserProfileUseCase implements Usecase<void, UserModel>{
    constructor(private userRepository: UserRepository){}
    execute(): Observable<UserModel> {
        return this.userRepository.getUserProfile();
    }
}
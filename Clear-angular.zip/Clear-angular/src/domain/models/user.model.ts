export interface UserModel{
    id: string;
    fullname: string;
    username: string;
    email?: string;
    phoneNum: string;
    createdAt: Date;
    profilePicture: string;
    activationStatus: boolean;
}
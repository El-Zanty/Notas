import  {Observable } from 'rxjs';
export interface Usecase<S, T> {
    execute(param: S): Observable<T>;
}
 export interface UserEntity{
    id: string;
    fullname: string;
    username: string;
    email?: string;
    phoneNum: string;
    createdAt: Date;
    profilePicture: string;
    activationStatus: boolean;
 /**  En algunos casos la informacion que se almacena en base datso cambia respecto ala informacion que solicita el api la infomacion de nuestra logica de negocio */
}
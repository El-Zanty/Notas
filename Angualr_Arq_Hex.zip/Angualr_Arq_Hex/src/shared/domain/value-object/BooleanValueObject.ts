import { ValueObject } from './ValueObject'

export abstract class BooleanValueObject extends ValueObject<boolean> {}

export class InvalidArgumentError extends Error {}

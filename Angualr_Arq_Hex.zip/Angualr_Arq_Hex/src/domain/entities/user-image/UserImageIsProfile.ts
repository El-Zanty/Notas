import { BooleanValueObject } from '@shared/domain/value-object/BooleanValueObject'

export class UserImageIsProfile extends BooleanValueObject {}

import { StringValueObject } from '@shared/domain/value-object/StringValueObject'

export class UserImageFileName extends StringValueObject {}

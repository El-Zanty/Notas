export interface UuidGenerator {
  generate: () => string
}

const userQueries = {
  user: (_: any, args: any) => []
}

export default userQueries
